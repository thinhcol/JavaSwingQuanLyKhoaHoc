public interface GridChangedListener {

	public void gridChanged(int columns, int rows);
	
}
